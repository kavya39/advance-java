package program1two;
import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		float []length=new float[5];
	    float []width=new float[5];
		System.out.println("enter the five length ");
		Scanner scan = new Scanner(System.in);
		for(int index = 0; index < 5; index++) {
			length[index] = scan.nextFloat();
			}
		System.out.println("enter the five width ");
		for(int index = 0; index < 5; index++) {
			width[index] = scan.nextFloat();
		}
		scan.close();
		Rectangle obj1=new Rectangle(length[0], width[0]);
		Rectangle obj2=new Rectangle(length[1], width[1]);
		Rectangle obj3=new Rectangle(length[2], width[2]);
	    Rectangle obj4=new Rectangle(length[3], width[3]);
		Rectangle obj5=new Rectangle(length[4], width[4]);
	}
}
